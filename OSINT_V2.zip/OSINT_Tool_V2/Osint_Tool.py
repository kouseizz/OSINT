import os
import json
import socket
import urllib.request
import webbrowser
from pystyle import *
from PIL import Image
from PIL.ExifTags import TAGS

def clear():
    os.system("cls" if os.name == "nt" else "clear")

os.system('title [+] Tool by Anonymcore')

def blue(text):
    print(Colorate.Horizontal(Colors.green_to_yellow, text))

banner = r"""
⠀⠀⠀⠀⡀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ 
⠀⠀⠀⣾⠁⠀⠀⣸⠆⠀⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣿⣄⠀⣼⡟⠀⠀⠀⠉⠉⠛ ⠷⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢀⣾⠀⠘⢿⣷⣿⣷⣠⡶⠛⠛⠛⠷⣦⠈⢻⠂⠀⠀⠀⠀⠀⠀⠀⠀ ⠀██████╗ ███████╗██╗███╗   ██╗████████╗
⢸⠇⠀⠀⡟⢛⣻⣿⡏⠀⠀⠀⠀⠀ ⠸⣧⠀⠀⣦⠀⠀⠀⠀⠀⠀⠀██╔═══██╗██╔════╝██║████╗  ██║╚══██╔══╝
⣾⠀⠀⠰⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀ ⢠⡿⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀██║   ██║███████╗██║██╔██╗ ██║   ██║   
⢸⡀⠀⠀⢻⣿⠿⣿⣿⣦⣀⡀⣀⣠⡾⠁⠀⠀⣿⠀⠀⠀⠀⠀⠀ ⠀██║   ██║╚════██║██║██║╚██╗██║   ██║   
⠘⣧⡀⠀⠀⠀⠀⣼⣿⣯⡉⠉⠉⠙⣇⡀⠀⢰⡏⠀⠀⠀⠀⠀⠀  ╚██████╔╝███████║██║██║ ╚████║   ██║   
⠀⠘⢷⡄⠀⣠⣾⣿⣿⣿⣿⠄⠀⠀⢹⣷⡄⠘⠀⠀⠀⠀⠀⠀⠀⠀⠀ ╚═════╝ ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝   
⠀⠀⠀⠀⢾⣿⣿⣿⣿⣿⠟⠀⣀⣠⠀⢻⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠛⠁⠀⠚⠋⠉⠀⠀⠻⡿⠆
  ╭───────────────╮ ╭───────────────────────╮ ╭─────────────────╮
  │ DEV : Kil1l   │ │ discord.gg/qJxYDurpKk │ │ Version : 1.0.0 │
  ╰───────────────╯ ╰───────────────────────╯ ╰─────────────────╯
"""

def header(title):
    clear()
    blue(banner)
    blue(f"[ {title} ]\n")

def ip_osint():
    header("IP OSINT Lookup")
    ip = input(Colorate.Horizontal(Colors.green_to_yellow, "IP address: "))

    try:
        hostname = socket.gethostbyaddr(ip)[0] if ip else "N/A"
    except:
        hostname = "N/A"

    try:
        url = f"http://ip-api.com/json/{ip}?fields=66846719"
        data = json.loads(urllib.request.urlopen(url).read())

        results = {
            "IP": data.get("query", "N/A"),
            "Status": data.get("status", "N/A"),
            "Country": f"{data.get('country', 'N/A')} ({data.get('countryCode', 'N/A')})",
            "Region": f"{data.get('regionName', 'N/A')} ({data.get('region', 'N/A')})",
            "City": data.get("city", "N/A"),
            "ZIP": data.get("zip", "N/A"),
            "Latitude": data.get("lat", "N/A"),
            "Longitude": data.get("lon", "N/A"),
            "Timezone": data.get("timezone", "N/A"),
            "ISP": data.get("isp", "N/A"),
            "Organisation": data.get("org", "N/A"),
            "AS": data.get("as", "N/A"),
            "Mobile": data.get("mobile", "N/A"),
            "Proxy": data.get("proxy", "N/A"),
            "Hosting": data.get("hosting", "N/A"),
            "Reverse DNS": hostname
        }

        for k, v in results.items():
            blue(f"{k}: {v}")

    except:
        blue("IP lookup failed.")

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def domain_osint():
    header("Domain OSINT")
    domain = input(Colorate.Horizontal(Colors.green_to_yellow, "Domain: "))

    try:
        ip = socket.gethostbyname(domain)
        blue(f"Resolved IP: {ip}")
    except:
        blue("DNS resolve failed.")

    webbrowser.open(f"https://who.is/whois/{domain}")
    webbrowser.open("https://dnsdumpster.com")
    webbrowser.open(f"https://viewdns.info/reverseip/?host={domain}")

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def dns_lookup():
    header("DNS Lookup")
    domain = input(Colorate.Horizontal(Colors.green_to_yellow, "Domain: "))

    try:
        result = socket.gethostbyname_ex(domain)
        blue(f"Full DNS Info: {result}")
    except:
        blue("DNS lookup failed.")

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def subdomain_osint():
    header("Subdomain OSINT")
    domain = input(Colorate.Horizontal(Colors.green_to_yellow, "Domain: "))

    blue("Opening certificate transparency search (crt.sh)")
    webbrowser.open(f"https://crt.sh/?q=%25.{domain}")
    webbrowser.open(f"https://subdomainfinder.c99.nl/?domain={domain}")

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def whois_osint():
    header("WHOIS OSINT")
    domain = input(Colorate.Horizontal(Colors.green_to_yellow, "Domain: "))

    blue("Opening WHOIS information")
    webbrowser.open(f"https://who.is/whois/{domain}")
    webbrowser.open(f"https://www.whois.com/whois/{domain}")

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def username_osint():
    header("Username OSINT")
    user = input(Colorate.Horizontal(Colors.green_to_yellow, "Username: "))

    sites = [
    "github.com", "gitlab.com", "bitbucket.org", "reddit.com/user",
    "twitter.com", "x.com", "instagram.com", "tiktok.com/@", "youtube.com/@",
    "twitch.tv", "kick.com", "steamcommunity.com/id", "steamcommunity.com/profiles",
    "pinterest.com", "soundcloud.com", "keybase.io", "medium.com/@",
    "deviantart.com", "about.me", "flickr.com/people", "pastebin.com/u",
    "tryhackme.com/p", "hackthebox.com/profile", "stackoverflow.com/users",
    "superuser.com/users", "serverfault.com/users", "discord.gg",
    "behance.net", "dribbble.com", "tumblr.com", "vk.com", "ok.ru",
    "weibo.com", "mastodon.social/@", "threads.net/@", "snapchat.com/add",
    "facebook.com", "linkedin.com/in", "vimeo.com", "dailymotion.com",
    "odysee.com/@", "rumble.com/user", "artstation.com", "500px.com",
    "replit.com/@", "codepen.io", "npmjs.com/~", "pypi.org/user",
    "crates.io/users", "launchpad.net/~", "sourceforge.net/u",
    "bugcrowd.com", "hackerone.com", "intigriti.com/profile",
    "exploit-db.com/author", "packetstormsecurity.com/users",
    "faceit.com/en/players", "tracker.gg", "epicgames.com/id",
    "playstation.com/en-us/users", "xboxgamertag.com/search",
    "forum.xda-developers.com/m", "blackhatworld.com/members",
    "nulled.to", "cracked.io",

    "ask.fm", "tellonym.me", "curiouscat.me",
    "imgur.com/user", "gfycat.com", "tenor.com/users",
    "scribd.com", "slideshare.net",
    "goodreads.com/user/show",
    "last.fm/user", "bandcamp.com",
    "mixcloud.com", "audiomack.com",
    "open.spotify.com/user",

    "itch.io", "gamejolt.com/@",
    "speedrun.com/user",
    "chess.com/member", "lichess.org/@",

    "patreon.com", "ko-fi.com", "buymeacoffee.com",
    "gumroad.com",

    "producthunt.com/@",
    "angel.co/u",
    "researchgate.net/profile",
    "academia.edu",

    "etsy.com/shop",
    "ebay.com/usr",
    "fiverr.com",
    "upwork.com/freelancers",

    "quora.com/profile",
    "wikidot.com/user:info",
    "instructables.com/member",

    "forum.bitcoin.com/u",
    "bitcointalk.org/index.php?action=profile;u=",
    "etherscan.io/address",
    "opensea.io",

    "namechk.com",
    "knowem.com"
    ]

    blue("Opening possible accounts...")

    for site in sites:
        webbrowser.open(f"https://{site}/{user}")

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def email_osint():
    header("Email OSINT")
    email = input(Colorate.Horizontal(Colors.green_to_yellow,"Email address: "))

    blue("Opening breach and reputation checks...")
    webbrowser.open(f"https://haveibeenpwned.com/unifiedsearch/{email}")
    webbrowser.open(f"https://emailrep.io/{email}")
    webbrowser.open(f"https://www.email-checker.net/{email}")
    webbrowser.open(f"https://tools.verifyemailaddress.io/?email={email}")
    webbrowser.open(f"https://emailverification.whoisxmlapi.com/lookup?emailAddress={email}")
    webbrowser.open(f"https://hunter.io/email-verifier/{email}")
    webbrowser.open(f"https://clearbit.com/email/{email}")
    webbrowser.open(f"https://thatsthem.com/email/{email}")
    webbrowser.open(f"https://www.skymem.info/srch?q={email}")
    webbrowser.open(f"https://psbdmp.ws/api/search/{email}")
    webbrowser.open(f"https://intelx.io/?s={email}")
    webbrowser.open(f"https://www.google.com/search?q=%22{email}%22")
    webbrowser.open(f"https://www.bing.com/search?q=%22{email}%22")
    webbrowser.open(f"https://yandex.com/search/?text={email}")
    webbrowser.open(f"https://github.com/search?q={email}")
    webbrowser.open(f"https://pastebin.com/search?q={email}")
    webbrowser.open(f"https://www.reddit.com/search/?q={email}")
    webbrowser.open(f"https://twitter.com/search?q={email}")
    webbrowser.open(f"https://www.linkedin.com/search/results/all/?keywords={email}")
    webbrowser.open(f"https://www.facebook.com/search/top/?q={email}")
    webbrowser.open(f"https://www.gravatar.com/{email}")
    webbrowser.open(f"https://haveibeensold.app/?email={email}")

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def google_dork():
    header("Advanced Google Dork Generator")
    target = input(Colorate.Horizontal(Colors.green_to_yellow, "Domain or keyword: "))

    dorks = [
        f"site:{target}",
        f"site:{target} filetype:pdf",
        f"site:{target} filetype:doc OR docx",
        f"site:{target} filetype:xls OR xlsx",
        f"site:{target} filetype:txt",
        f"site:{target} filetype:log",
        f"site:{target} filetype:env",
        f"site:{target} filetype:sql",
        f"site:{target} filetype:bak",
        f"site:{target} filetype:old",
        f"site:{target} filetype:backup",
        f'intitle:"index of" "{target}"',
        f'intitle:"admin" "{target}"',
        f'intitle:"login" "{target}"',
        f'"{target}" "password"',
        f'"{target}" "credentials"',
        f'"{target}" "api_key"',
        f'"{target}" "secret"',
        f'"{target}" "confidential"',
        f'"{target}" "@gmail.com"',
        f'"{target}" "@proton.me"',
        f'"{target}" "@outlook.com"',
        f'"{target}" "internal"',
        f'"{target}" "restricted"',
        f'"{target}" "do not share"',
    ]

    blue("\nGenerated Google Dorks:\n")

    for d in dorks:
        blue(d)

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def exif_osint():
    header("EXIF Metadata OSINT")
    path = input(Colorate.Horizontal(Colors.green_to_yellow, "Image path: "))

    try:
        img = Image.open(path)
        exif = img._getexif()

        if not exif:
            blue("No EXIF metadata found.")
        else:
            for tag_id, value in exif.items():
                tag = TAGS.get(tag_id, tag_id)
                blue(f"{tag}: {value}")
    except:
        blue("Failed to extract metadata.")

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def reverse_image():
    header("Reverse Image OSINT")

    blue("Opening reverse image search engines...")
    webbrowser.open("https://images.google.com")
    webbrowser.open("https://yandex.com/images/")
    webbrowser.open("https://tineye.com/")
    webbrowser.open("https://www.bing.com/visualsearch")
    webbrowser.open("https://image.baidu.com/")
    webbrowser.open("https://www.pixsy.com/")
    webbrowser.open("https://berify.com/")
    webbrowser.open("https://lens.google.com/")
    webbrowser.open("https://pimeyes.com/")
    webbrowser.open("https://facecheck.id/")
    webbrowser.open("https://socialcatfish.com/")
    webbrowser.open("https://www.duplichecker.com/reverse-image-search.php")
    webbrowser.open("https://smallseotools.com/reverse-image-search/")
    webbrowser.open("https://www.labnol.org/reverse/")
    webbrowser.open("https://www.imageraider.com/")

    input(Colorate.Horizontal(Colors.green_to_yellow, "\nPress Enter..."))

def main():
    while True:
        clear()
        blue(banner)
        blue("""
[1] IP OSINT Lookup
[2] Domain OSINT
[3] DNS Lookup
[4] Subdomain OSINT
[5] WHOIS OSINT
[6] Username OSINT 
[7] Email OSINT 
[8] Google Dork Generator 
[9] EXIF OSINT
[10] Reverse Image OSINT
[0] Exit
""")
        print()
        print(Colorate.Horizontal(Colors.green_to_yellow, "┌──(root㉿Osint)-[~]"))
        choice = input(Colorate.Horizontal(Colors.green_to_yellow, "└─$ "))

        if choice == "1": ip_osint()
        elif choice == "2": domain_osint()
        elif choice == "3": dns_lookup()
        elif choice == "4": subdomain_osint()
        elif choice == "5": whois_osint()
        elif choice == "6": username_osint()
        elif choice == "7": email_osint()
        elif choice == "8": google_dork()
        elif choice == "9": exif_osint()
        elif choice == "10": reverse_image()
        elif choice == "0": break

main()
