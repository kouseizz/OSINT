import os
import subprocess
import sys

required_packages = [
    "pystyle",
    "Pillow",
    "json",
    "socket",
    "PIL"
]

def install_package(package):
    try:
        print(f"Installing {package}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"{package} installed successfully.\n")
    except subprocess.CalledProcessError:
        print(f"Failed to install {package}.\n")

def main():
    print("\n=== Python OSINT Tool Installer ===\n")

    if sys.version_info < (3, 10):
        print(f"Warning: You are using Python {sys.version_info.major}.{sys.version_info.minor}. "
              "Python 3.10+ is recommended.\n")

    for pkg in required_packages:
        try:
            __import__(pkg)
            print(f"{pkg} is already installed.\n")
        except ImportError:
            install_package(pkg)

    print("All required packages are installed.")
    input("Press Enter to exit installer...")

if __name__ == "__main__":
    main()
